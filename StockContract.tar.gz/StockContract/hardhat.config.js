require("@nomicfoundation/hardhat-toolbox");

task("transferStock", "Transfer stock between accounts")
  .addParam("accounta", "The sender's address") // 全部小寫
  .addParam("accountb", "The receiver's address")
  .addParam("amount", "The amount of stock to transfer")
  .setAction(async (taskArgs, hre) => {
    const { accounta, accountb, amount } = taskArgs;
    const script = require("./scripts/transferStock.js");
    await script.main(accounta, accountb, amount);
  });




/** @type import('hardhat/config').HardhatUserConfig */
module.exports = {
  solidity: "0.8.28",
  networks: {
    localhost: {
      url: "http://127.0.0.1:8545", // Hardhat 本地網絡
    },
  },
  paths: {
    sources: "./contracts",
    tests: "./test",
    cache: "./cache",
    artifacts: "./artifacts",
  },
};
